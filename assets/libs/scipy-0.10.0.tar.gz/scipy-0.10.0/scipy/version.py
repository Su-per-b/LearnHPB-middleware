
# THIS FILE IS GENERATED FROM SCIPY SETUP.PY
short_version = '0.10.0'
version = '0.10.0'
full_version = '0.10.0'
git_revision = 'c82deecb7c99af5c775a710974761896d623f155'
release = True

if not release:
    version = full_version
