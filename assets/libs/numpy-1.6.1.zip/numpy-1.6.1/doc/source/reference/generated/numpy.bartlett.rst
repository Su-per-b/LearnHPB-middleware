numpy.bartlett
==============

.. currentmodule:: numpy

.. autofunction:: bartlett