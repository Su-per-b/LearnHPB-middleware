numpy.core.defchararray.isupper
===============================

.. currentmodule:: numpy.core.defchararray

.. autofunction:: isupper