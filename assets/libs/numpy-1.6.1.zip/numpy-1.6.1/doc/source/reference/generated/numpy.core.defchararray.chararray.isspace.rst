numpy.core.defchararray.chararray.isspace
=========================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.isspace