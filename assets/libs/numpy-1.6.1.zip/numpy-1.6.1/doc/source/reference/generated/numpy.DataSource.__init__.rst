numpy.DataSource.__init__
=========================

.. currentmodule:: numpy

.. automethod:: DataSource.__init__