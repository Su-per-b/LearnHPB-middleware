numpy.blackman
==============

.. currentmodule:: numpy

.. autofunction:: blackman