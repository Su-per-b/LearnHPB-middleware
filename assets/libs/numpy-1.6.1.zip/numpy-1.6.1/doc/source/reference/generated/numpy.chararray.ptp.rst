numpy.chararray.ptp
===================

.. currentmodule:: numpy

.. automethod:: chararray.ptp