numpy.DataSource.abspath
========================

.. currentmodule:: numpy

.. automethod:: DataSource.abspath