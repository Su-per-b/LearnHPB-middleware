numpy.array
===========

.. currentmodule:: numpy

.. autofunction:: array