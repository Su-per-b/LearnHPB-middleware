numpy.chararray.isnumeric
=========================

.. currentmodule:: numpy

.. automethod:: chararray.isnumeric