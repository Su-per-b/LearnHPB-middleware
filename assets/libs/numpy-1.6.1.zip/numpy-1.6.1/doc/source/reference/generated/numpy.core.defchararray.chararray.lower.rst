numpy.core.defchararray.chararray.lower
=======================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.lower