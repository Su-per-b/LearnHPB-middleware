numpy.core.defchararray.upper
=============================

.. currentmodule:: numpy.core.defchararray

.. autofunction:: upper