numpy.core.defchararray.chararray.tolist
========================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.tolist