numpy.apply_along_axis
======================

.. currentmodule:: numpy

.. autofunction:: apply_along_axis