numpy.chararray.max
===================

.. currentmodule:: numpy

.. automethod:: chararray.max