numpy.distutils.misc_util.get_numpy_include_dirs
================================================

.. currentmodule:: numpy.distutils.misc_util

.. autofunction:: get_numpy_include_dirs