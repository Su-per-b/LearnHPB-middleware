numpy.core.defchararray.startswith
==================================

.. currentmodule:: numpy.core.defchararray

.. autofunction:: startswith