numpy.delete
============

.. currentmodule:: numpy

.. autofunction:: delete