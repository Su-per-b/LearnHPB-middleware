numpy.chararray.data
====================

.. currentmodule:: numpy

.. autoattribute:: chararray.data