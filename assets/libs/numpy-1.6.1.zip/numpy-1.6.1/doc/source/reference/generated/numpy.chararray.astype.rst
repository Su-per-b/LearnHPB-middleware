numpy.chararray.astype
======================

.. currentmodule:: numpy

.. automethod:: chararray.astype