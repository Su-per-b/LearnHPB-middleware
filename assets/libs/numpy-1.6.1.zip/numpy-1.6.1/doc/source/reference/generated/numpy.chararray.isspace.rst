numpy.chararray.isspace
=======================

.. currentmodule:: numpy

.. automethod:: chararray.isspace