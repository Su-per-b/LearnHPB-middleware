numpy.core.defchararray.chararray.rstrip
========================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.rstrip