numpy.bmat
==========

.. currentmodule:: numpy

.. autofunction:: bmat