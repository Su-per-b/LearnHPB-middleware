numpy.core.defchararray.rsplit
==============================

.. currentmodule:: numpy.core.defchararray

.. autofunction:: rsplit