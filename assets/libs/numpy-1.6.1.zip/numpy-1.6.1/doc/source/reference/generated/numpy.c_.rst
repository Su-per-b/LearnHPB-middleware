numpy.c_
========

.. currentmodule:: numpy

.. autodata:: c_