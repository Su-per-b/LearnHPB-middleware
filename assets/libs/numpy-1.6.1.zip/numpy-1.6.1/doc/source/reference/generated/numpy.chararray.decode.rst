numpy.chararray.decode
======================

.. currentmodule:: numpy

.. automethod:: chararray.decode