numpy.chararray.ndim
====================

.. currentmodule:: numpy

.. autoattribute:: chararray.ndim