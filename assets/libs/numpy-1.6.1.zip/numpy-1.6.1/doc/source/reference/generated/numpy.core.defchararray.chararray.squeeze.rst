numpy.core.defchararray.chararray.squeeze
=========================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.squeeze