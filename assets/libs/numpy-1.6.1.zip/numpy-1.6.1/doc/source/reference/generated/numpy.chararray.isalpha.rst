numpy.chararray.isalpha
=======================

.. currentmodule:: numpy

.. automethod:: chararray.isalpha