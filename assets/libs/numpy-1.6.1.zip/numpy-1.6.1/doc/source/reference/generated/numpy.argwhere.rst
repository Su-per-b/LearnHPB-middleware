numpy.argwhere
==============

.. currentmodule:: numpy

.. autofunction:: argwhere