numpy.distutils.cpuinfo.cpu
===========================

.. currentmodule:: numpy.distutils.cpuinfo

.. autodata:: cpu