numpy.core.defchararray.replace
===============================

.. currentmodule:: numpy.core.defchararray

.. autofunction:: replace