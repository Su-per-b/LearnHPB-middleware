numpy.chararray.tofile
======================

.. currentmodule:: numpy

.. automethod:: chararray.tofile