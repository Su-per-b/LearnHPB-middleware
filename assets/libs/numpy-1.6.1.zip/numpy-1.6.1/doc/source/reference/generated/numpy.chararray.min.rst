numpy.chararray.min
===================

.. currentmodule:: numpy

.. automethod:: chararray.min