numpy.broadcast.reset
=====================

.. currentmodule:: numpy

.. automethod:: broadcast.reset