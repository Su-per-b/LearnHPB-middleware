numpy.core.defchararray.chararray.shape
=======================================

.. currentmodule:: numpy.core.defchararray

.. autoattribute:: chararray.shape