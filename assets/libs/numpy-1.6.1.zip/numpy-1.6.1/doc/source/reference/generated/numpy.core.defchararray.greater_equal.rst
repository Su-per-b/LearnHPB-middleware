numpy.core.defchararray.greater_equal
=====================================

.. currentmodule:: numpy.core.defchararray

.. autofunction:: greater_equal