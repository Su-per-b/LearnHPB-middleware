numpy.chararray.real
====================

.. currentmodule:: numpy

.. autoattribute:: chararray.real