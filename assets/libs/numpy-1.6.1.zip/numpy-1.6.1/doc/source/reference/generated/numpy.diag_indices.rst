numpy.diag_indices
==================

.. currentmodule:: numpy

.. autofunction:: diag_indices