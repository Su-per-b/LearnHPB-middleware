numpy.core.defchararray.partition
=================================

.. currentmodule:: numpy.core.defchararray

.. autofunction:: partition