numpy.base_repr
===============

.. currentmodule:: numpy

.. autofunction:: base_repr