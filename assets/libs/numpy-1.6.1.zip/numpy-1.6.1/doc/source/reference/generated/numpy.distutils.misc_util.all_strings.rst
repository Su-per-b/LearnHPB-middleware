numpy.distutils.misc_util.all_strings
=====================================

.. currentmodule:: numpy.distutils.misc_util

.. autofunction:: all_strings