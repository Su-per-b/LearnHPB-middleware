numpy.core.defchararray.chararray.any
=====================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.any