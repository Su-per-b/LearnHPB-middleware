numpy.core.defchararray.isnumeric
=================================

.. currentmodule:: numpy.core.defchararray

.. autofunction:: isnumeric