numpy.chararray.T
=================

.. currentmodule:: numpy

.. autoattribute:: chararray.T