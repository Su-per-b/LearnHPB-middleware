numpy.chararray.endswith
========================

.. currentmodule:: numpy

.. automethod:: chararray.endswith