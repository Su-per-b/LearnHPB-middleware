numpy.argmin
============

.. currentmodule:: numpy

.. autofunction:: argmin