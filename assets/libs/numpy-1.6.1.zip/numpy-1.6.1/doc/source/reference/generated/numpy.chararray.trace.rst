numpy.chararray.trace
=====================

.. currentmodule:: numpy

.. automethod:: chararray.trace