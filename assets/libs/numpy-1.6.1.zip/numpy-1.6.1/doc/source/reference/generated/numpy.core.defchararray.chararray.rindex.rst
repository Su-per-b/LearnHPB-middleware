numpy.core.defchararray.chararray.rindex
========================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.rindex