numpy.chararray.flatten
=======================

.. currentmodule:: numpy

.. automethod:: chararray.flatten