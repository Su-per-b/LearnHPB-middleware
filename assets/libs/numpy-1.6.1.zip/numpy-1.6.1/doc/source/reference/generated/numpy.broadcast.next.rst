numpy.broadcast.next
====================

.. currentmodule:: numpy

.. automethod:: broadcast.next