numpy.distutils.misc_util.get_cmd
=================================

.. currentmodule:: numpy.distutils.misc_util

.. autofunction:: get_cmd