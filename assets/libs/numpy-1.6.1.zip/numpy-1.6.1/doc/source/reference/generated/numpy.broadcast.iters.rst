numpy.broadcast.iters
=====================

.. currentmodule:: numpy

.. autoattribute:: broadcast.iters