numpy.distutils.misc_util.blue_text
===================================

.. currentmodule:: numpy.distutils.misc_util

.. autofunction:: blue_text