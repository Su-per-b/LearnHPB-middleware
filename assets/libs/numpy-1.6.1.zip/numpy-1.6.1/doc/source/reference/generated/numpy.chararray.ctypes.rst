numpy.chararray.ctypes
======================

.. currentmodule:: numpy

.. autoattribute:: chararray.ctypes