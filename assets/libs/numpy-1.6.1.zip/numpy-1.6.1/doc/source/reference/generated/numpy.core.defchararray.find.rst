numpy.core.defchararray.find
============================

.. currentmodule:: numpy.core.defchararray

.. autofunction:: find