numpy.chararray.imag
====================

.. currentmodule:: numpy

.. autoattribute:: chararray.imag