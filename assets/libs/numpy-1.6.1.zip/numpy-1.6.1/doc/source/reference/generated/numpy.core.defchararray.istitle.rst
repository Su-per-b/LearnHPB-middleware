numpy.core.defchararray.istitle
===============================

.. currentmodule:: numpy.core.defchararray

.. autofunction:: istitle