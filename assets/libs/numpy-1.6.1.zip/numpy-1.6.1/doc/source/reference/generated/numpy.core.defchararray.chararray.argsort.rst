numpy.core.defchararray.chararray.argsort
=========================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.argsort