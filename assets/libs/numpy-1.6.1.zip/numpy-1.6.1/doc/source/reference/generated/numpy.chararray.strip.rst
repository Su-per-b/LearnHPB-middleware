numpy.chararray.strip
=====================

.. currentmodule:: numpy

.. automethod:: chararray.strip