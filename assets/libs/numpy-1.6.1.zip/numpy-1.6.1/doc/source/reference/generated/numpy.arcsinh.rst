numpy.arcsinh
=============

.. currentmodule:: numpy

.. autodata:: arcsinh