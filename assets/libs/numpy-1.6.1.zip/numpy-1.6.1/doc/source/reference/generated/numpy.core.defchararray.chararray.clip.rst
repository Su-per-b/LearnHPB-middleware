numpy.core.defchararray.chararray.clip
======================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.clip