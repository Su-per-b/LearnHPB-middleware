numpy.core.records.array
========================

.. currentmodule:: numpy.core.records

.. autofunction:: array