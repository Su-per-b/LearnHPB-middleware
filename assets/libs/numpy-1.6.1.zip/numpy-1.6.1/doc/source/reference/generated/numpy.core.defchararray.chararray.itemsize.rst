numpy.core.defchararray.chararray.itemsize
==========================================

.. currentmodule:: numpy.core.defchararray

.. autoattribute:: chararray.itemsize