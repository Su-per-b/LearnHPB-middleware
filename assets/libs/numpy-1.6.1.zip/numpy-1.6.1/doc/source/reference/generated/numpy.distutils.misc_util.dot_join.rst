numpy.distutils.misc_util.dot_join
==================================

.. currentmodule:: numpy.distutils.misc_util

.. autofunction:: dot_join