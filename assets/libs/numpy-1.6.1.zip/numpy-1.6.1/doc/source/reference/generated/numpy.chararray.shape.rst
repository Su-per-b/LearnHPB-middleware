numpy.chararray.shape
=====================

.. currentmodule:: numpy

.. autoattribute:: chararray.shape