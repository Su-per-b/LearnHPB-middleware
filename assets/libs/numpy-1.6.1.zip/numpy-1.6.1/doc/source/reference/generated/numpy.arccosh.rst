numpy.arccosh
=============

.. currentmodule:: numpy

.. autodata:: arccosh