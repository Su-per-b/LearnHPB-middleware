numpy.core.defchararray.chararray.isupper
=========================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.isupper