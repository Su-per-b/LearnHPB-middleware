numpy.core.defchararray.center
==============================

.. currentmodule:: numpy.core.defchararray

.. autofunction:: center