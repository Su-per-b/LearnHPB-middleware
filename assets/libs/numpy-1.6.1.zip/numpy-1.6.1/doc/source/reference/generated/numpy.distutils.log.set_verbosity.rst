numpy.distutils.log.set_verbosity
=================================

.. currentmodule:: numpy.distutils.log

.. autofunction:: set_verbosity