numpy.ceil
==========

.. currentmodule:: numpy

.. autodata:: ceil