numpy.bitwise_or
================

.. currentmodule:: numpy

.. autodata:: bitwise_or