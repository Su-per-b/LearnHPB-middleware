numpy.core.defchararray.rjust
=============================

.. currentmodule:: numpy.core.defchararray

.. autofunction:: rjust