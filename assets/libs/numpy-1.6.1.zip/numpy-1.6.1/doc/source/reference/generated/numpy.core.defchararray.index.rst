numpy.core.defchararray.index
=============================

.. currentmodule:: numpy.core.defchararray

.. autofunction:: index