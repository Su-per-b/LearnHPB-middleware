numpy.distutils.misc_util.cyg2win32
===================================

.. currentmodule:: numpy.distutils.misc_util

.. autofunction:: cyg2win32