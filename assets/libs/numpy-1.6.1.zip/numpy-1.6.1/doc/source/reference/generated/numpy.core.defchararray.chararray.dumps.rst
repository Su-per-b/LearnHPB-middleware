numpy.core.defchararray.chararray.dumps
=======================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.dumps