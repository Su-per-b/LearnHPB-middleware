numpy.arctan
============

.. currentmodule:: numpy

.. autodata:: arctan