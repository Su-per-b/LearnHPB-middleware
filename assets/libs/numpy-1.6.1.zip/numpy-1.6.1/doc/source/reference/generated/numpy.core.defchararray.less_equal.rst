numpy.core.defchararray.less_equal
==================================

.. currentmodule:: numpy.core.defchararray

.. autofunction:: less_equal