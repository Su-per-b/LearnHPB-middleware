numpy.core.defchararray.chararray.dot
=====================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.dot