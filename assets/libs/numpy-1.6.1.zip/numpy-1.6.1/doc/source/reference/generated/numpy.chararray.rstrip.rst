numpy.chararray.rstrip
======================

.. currentmodule:: numpy

.. automethod:: chararray.rstrip