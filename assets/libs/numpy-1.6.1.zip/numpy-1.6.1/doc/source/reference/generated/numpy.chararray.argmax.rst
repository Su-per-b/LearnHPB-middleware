numpy.chararray.argmax
======================

.. currentmodule:: numpy

.. automethod:: chararray.argmax