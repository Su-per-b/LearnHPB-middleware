numpy.chararray.swapcase
========================

.. currentmodule:: numpy

.. automethod:: chararray.swapcase