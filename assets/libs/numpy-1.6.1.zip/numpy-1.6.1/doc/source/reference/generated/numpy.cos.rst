numpy.cos
=========

.. currentmodule:: numpy

.. autodata:: cos