numpy.chararray.rfind
=====================

.. currentmodule:: numpy

.. automethod:: chararray.rfind