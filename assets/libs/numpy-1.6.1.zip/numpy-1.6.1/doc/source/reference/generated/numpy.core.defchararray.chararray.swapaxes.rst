numpy.core.defchararray.chararray.swapaxes
==========================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.swapaxes