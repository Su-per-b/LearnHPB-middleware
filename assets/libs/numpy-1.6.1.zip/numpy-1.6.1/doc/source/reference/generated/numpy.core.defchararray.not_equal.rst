numpy.core.defchararray.not_equal
=================================

.. currentmodule:: numpy.core.defchararray

.. autofunction:: not_equal