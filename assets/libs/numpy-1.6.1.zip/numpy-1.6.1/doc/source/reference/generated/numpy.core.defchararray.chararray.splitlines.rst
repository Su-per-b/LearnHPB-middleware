numpy.core.defchararray.chararray.splitlines
============================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.splitlines