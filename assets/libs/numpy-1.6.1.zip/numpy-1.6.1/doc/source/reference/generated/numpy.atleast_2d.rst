numpy.atleast_2d
================

.. currentmodule:: numpy

.. autofunction:: atleast_2d