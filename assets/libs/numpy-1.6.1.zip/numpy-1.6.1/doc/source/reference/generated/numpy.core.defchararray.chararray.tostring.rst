numpy.core.defchararray.chararray.tostring
==========================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.tostring