numpy.core.defchararray.rpartition
==================================

.. currentmodule:: numpy.core.defchararray

.. autofunction:: rpartition