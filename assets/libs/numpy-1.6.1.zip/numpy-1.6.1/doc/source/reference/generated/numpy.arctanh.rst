numpy.arctanh
=============

.. currentmodule:: numpy

.. autodata:: arctanh