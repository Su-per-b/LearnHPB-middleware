numpy.core.defchararray.chararray.argmax
========================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.argmax