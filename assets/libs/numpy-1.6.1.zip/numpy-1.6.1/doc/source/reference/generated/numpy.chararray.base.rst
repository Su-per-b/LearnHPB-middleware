numpy.chararray.base
====================

.. currentmodule:: numpy

.. autoattribute:: chararray.base