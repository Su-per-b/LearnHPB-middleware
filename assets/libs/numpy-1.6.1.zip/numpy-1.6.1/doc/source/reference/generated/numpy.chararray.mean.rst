numpy.chararray.mean
====================

.. currentmodule:: numpy

.. automethod:: chararray.mean