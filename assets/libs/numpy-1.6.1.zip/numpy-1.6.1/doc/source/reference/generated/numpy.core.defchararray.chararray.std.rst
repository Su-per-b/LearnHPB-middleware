numpy.core.defchararray.chararray.std
=====================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.std