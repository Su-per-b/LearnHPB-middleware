numpy.chararray.rpartition
==========================

.. currentmodule:: numpy

.. automethod:: chararray.rpartition