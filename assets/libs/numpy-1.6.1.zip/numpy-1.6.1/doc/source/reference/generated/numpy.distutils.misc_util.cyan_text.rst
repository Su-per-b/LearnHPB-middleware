numpy.distutils.misc_util.cyan_text
===================================

.. currentmodule:: numpy.distutils.misc_util

.. autofunction:: cyan_text