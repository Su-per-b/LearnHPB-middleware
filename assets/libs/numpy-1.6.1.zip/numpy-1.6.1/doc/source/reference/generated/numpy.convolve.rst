numpy.convolve
==============

.. currentmodule:: numpy

.. autofunction:: convolve