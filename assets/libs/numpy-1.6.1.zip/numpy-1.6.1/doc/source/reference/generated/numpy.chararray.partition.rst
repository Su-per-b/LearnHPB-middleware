numpy.chararray.partition
=========================

.. currentmodule:: numpy

.. automethod:: chararray.partition