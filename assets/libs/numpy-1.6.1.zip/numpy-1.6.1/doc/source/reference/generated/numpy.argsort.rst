numpy.argsort
=============

.. currentmodule:: numpy

.. autofunction:: argsort