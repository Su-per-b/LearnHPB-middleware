numpy.core.defchararray.title
=============================

.. currentmodule:: numpy.core.defchararray

.. autofunction:: title