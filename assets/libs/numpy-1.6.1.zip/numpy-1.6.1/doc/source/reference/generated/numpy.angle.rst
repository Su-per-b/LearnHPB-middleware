numpy.angle
===========

.. currentmodule:: numpy

.. autofunction:: angle