numpy.core.defchararray.equal
=============================

.. currentmodule:: numpy.core.defchararray

.. autofunction:: equal