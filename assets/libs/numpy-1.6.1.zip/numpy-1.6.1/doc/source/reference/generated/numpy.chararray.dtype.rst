numpy.chararray.dtype
=====================

.. currentmodule:: numpy

.. autoattribute:: chararray.dtype