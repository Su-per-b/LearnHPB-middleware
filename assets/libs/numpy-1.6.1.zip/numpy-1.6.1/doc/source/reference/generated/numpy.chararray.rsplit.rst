numpy.chararray.rsplit
======================

.. currentmodule:: numpy

.. automethod:: chararray.rsplit