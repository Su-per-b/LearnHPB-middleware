numpy.core.defchararray.add
===========================

.. currentmodule:: numpy.core.defchararray

.. autofunction:: add