numpy.amin
==========

.. currentmodule:: numpy

.. autofunction:: amin