numpy.corrcoef
==============

.. currentmodule:: numpy

.. autofunction:: corrcoef