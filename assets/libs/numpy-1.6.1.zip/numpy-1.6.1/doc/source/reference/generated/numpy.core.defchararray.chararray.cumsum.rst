numpy.core.defchararray.chararray.cumsum
========================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.cumsum