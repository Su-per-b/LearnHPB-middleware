numpy.chararray.zfill
=====================

.. currentmodule:: numpy

.. automethod:: chararray.zfill