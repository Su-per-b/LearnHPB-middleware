numpy.around
============

.. currentmodule:: numpy

.. autofunction:: around