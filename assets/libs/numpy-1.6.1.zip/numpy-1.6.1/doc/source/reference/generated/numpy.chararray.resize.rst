numpy.chararray.resize
======================

.. currentmodule:: numpy

.. automethod:: chararray.resize