numpy.chararray.ljust
=====================

.. currentmodule:: numpy

.. automethod:: chararray.ljust