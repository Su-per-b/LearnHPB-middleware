numpy.chararray.replace
=======================

.. currentmodule:: numpy

.. automethod:: chararray.replace