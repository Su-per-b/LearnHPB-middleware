numpy.chararray.view
====================

.. currentmodule:: numpy

.. automethod:: chararray.view