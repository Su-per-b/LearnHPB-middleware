numpy.chararray.choose
======================

.. currentmodule:: numpy

.. automethod:: chararray.choose