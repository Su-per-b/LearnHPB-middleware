numpy.chararray.put
===================

.. currentmodule:: numpy

.. automethod:: chararray.put