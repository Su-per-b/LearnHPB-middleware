numpy.chararray.itemset
=======================

.. currentmodule:: numpy

.. automethod:: chararray.itemset