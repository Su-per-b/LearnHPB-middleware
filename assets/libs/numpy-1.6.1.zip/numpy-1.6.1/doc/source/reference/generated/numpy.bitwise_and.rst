numpy.bitwise_and
=================

.. currentmodule:: numpy

.. autodata:: bitwise_and