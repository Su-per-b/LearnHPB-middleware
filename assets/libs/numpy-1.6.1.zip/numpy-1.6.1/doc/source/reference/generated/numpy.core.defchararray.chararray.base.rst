numpy.core.defchararray.chararray.base
======================================

.. currentmodule:: numpy.core.defchararray

.. autoattribute:: chararray.base