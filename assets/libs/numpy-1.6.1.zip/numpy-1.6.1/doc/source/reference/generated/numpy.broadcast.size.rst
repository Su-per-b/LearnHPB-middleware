numpy.broadcast.size
====================

.. currentmodule:: numpy

.. autoattribute:: broadcast.size