numpy.core.defchararray.chararray.fill
======================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.fill