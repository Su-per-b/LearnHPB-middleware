numpy.core.defchararray.chararray.isdigit
=========================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.isdigit