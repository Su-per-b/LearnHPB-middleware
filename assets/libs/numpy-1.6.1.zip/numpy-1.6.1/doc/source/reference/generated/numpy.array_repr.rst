numpy.array_repr
================

.. currentmodule:: numpy

.. autofunction:: array_repr