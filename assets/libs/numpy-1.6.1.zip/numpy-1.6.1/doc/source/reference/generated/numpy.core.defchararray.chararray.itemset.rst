numpy.core.defchararray.chararray.itemset
=========================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.itemset