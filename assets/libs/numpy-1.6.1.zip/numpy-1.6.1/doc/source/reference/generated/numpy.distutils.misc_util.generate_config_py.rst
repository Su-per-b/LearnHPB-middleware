numpy.distutils.misc_util.generate_config_py
============================================

.. currentmodule:: numpy.distutils.misc_util

.. autofunction:: generate_config_py