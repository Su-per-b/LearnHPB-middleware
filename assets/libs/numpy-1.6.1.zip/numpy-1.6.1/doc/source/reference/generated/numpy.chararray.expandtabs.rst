numpy.chararray.expandtabs
==========================

.. currentmodule:: numpy

.. automethod:: chararray.expandtabs