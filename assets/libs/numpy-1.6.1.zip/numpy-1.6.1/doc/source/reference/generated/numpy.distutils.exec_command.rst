numpy.distutils.exec_command
============================

.. automodule:: numpy.distutils.exec_command

   
   
   .. rubric:: Functions

   .. autosummary::
   
      exec_command
      find_executable
      get_exception
      get_pythonexe
      is_sequence
      make_temp_file
      open_latin1
      quote_arg
      splitcmdline
      temp_file_name
      test
      test_cl
      test_execute_in
      test_nt
      test_posix
      test_svn
   
   

   
   
   

   
   
   