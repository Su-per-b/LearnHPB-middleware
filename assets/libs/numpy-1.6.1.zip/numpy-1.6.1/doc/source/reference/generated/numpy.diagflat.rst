numpy.diagflat
==============

.. currentmodule:: numpy

.. autofunction:: diagflat