numpy.arctan2
=============

.. currentmodule:: numpy

.. autodata:: arctan2