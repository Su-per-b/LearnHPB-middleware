numpy.core.defchararray.chararray.join
======================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.join