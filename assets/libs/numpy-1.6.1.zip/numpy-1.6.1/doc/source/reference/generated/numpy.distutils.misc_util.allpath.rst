numpy.distutils.misc_util.allpath
=================================

.. currentmodule:: numpy.distutils.misc_util

.. autofunction:: allpath