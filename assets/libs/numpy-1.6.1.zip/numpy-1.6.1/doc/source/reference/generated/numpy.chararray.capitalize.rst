numpy.chararray.capitalize
==========================

.. currentmodule:: numpy

.. automethod:: chararray.capitalize