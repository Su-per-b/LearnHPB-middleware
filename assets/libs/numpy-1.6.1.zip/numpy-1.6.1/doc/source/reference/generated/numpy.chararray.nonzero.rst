numpy.chararray.nonzero
=======================

.. currentmodule:: numpy

.. automethod:: chararray.nonzero