numpy.chararray.repeat
======================

.. currentmodule:: numpy

.. automethod:: chararray.repeat