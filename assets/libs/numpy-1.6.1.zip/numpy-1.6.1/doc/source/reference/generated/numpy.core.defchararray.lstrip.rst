numpy.core.defchararray.lstrip
==============================

.. currentmodule:: numpy.core.defchararray

.. autofunction:: lstrip