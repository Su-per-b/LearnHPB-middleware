numpy.compress
==============

.. currentmodule:: numpy

.. autofunction:: compress