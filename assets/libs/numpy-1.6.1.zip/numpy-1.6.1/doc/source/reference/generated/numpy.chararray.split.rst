numpy.chararray.split
=====================

.. currentmodule:: numpy

.. automethod:: chararray.split