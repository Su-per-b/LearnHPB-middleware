numpy.core.defchararray.chararray.setfield
==========================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.setfield