numpy.core.defchararray.join
============================

.. currentmodule:: numpy.core.defchararray

.. autofunction:: join