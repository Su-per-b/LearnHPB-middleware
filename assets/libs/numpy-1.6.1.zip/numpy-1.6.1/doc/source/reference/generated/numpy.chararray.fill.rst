numpy.chararray.fill
====================

.. currentmodule:: numpy

.. automethod:: chararray.fill