numpy.diag
==========

.. currentmodule:: numpy

.. autofunction:: diag