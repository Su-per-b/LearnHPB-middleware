numpy.core.defchararray.chararray.data
======================================

.. currentmodule:: numpy.core.defchararray

.. autoattribute:: chararray.data