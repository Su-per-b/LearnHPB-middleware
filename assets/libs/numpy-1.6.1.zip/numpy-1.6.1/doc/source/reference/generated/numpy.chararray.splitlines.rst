numpy.chararray.splitlines
==========================

.. currentmodule:: numpy

.. automethod:: chararray.splitlines