numpy.core.defchararray.splitlines
==================================

.. currentmodule:: numpy.core.defchararray

.. autofunction:: splitlines