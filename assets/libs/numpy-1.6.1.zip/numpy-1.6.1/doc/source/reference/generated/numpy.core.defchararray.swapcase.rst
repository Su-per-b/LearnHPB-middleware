numpy.core.defchararray.swapcase
================================

.. currentmodule:: numpy.core.defchararray

.. autofunction:: swapcase