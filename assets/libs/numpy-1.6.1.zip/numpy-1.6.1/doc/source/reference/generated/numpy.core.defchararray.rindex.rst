numpy.core.defchararray.rindex
==============================

.. currentmodule:: numpy.core.defchararray

.. autofunction:: rindex