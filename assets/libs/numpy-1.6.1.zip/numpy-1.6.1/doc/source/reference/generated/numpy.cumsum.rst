numpy.cumsum
============

.. currentmodule:: numpy

.. autofunction:: cumsum