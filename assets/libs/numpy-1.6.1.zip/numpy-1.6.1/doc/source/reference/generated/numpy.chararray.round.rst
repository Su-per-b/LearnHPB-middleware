numpy.chararray.round
=====================

.. currentmodule:: numpy

.. automethod:: chararray.round