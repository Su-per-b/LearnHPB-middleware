numpy.core.defchararray.chararray.tofile
========================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.tofile