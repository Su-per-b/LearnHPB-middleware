numpy.degrees
=============

.. currentmodule:: numpy

.. autodata:: degrees