numpy.chararray.searchsorted
============================

.. currentmodule:: numpy

.. automethod:: chararray.searchsorted