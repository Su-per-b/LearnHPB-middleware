numpy.core.defchararray.chararray.setflags
==========================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.setflags