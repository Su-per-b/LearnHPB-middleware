numpy.core.defchararray.chararray.split
=======================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.split