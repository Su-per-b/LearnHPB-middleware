numpy.chararray.cumprod
=======================

.. currentmodule:: numpy

.. automethod:: chararray.cumprod