numpy.asfortranarray
====================

.. currentmodule:: numpy

.. autofunction:: asfortranarray