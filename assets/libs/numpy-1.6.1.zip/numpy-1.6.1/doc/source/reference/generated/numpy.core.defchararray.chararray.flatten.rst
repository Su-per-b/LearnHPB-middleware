numpy.core.defchararray.chararray.flatten
=========================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.flatten