numpy.core.defchararray.chararray.cumprod
=========================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.cumprod