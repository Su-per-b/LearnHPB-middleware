numpy.arccos
============

.. currentmodule:: numpy

.. autodata:: arccos