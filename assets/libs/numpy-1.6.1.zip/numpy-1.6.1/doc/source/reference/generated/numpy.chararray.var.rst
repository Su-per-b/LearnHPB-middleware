numpy.chararray.var
===================

.. currentmodule:: numpy

.. automethod:: chararray.var