numpy.chararray.count
=====================

.. currentmodule:: numpy

.. automethod:: chararray.count