numpy.all
=========

.. currentmodule:: numpy

.. autofunction:: all