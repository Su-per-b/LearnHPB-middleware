numpy.broadcast.index
=====================

.. currentmodule:: numpy

.. autoattribute:: broadcast.index