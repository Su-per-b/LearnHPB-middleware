numpy.core.defchararray.chararray.isnumeric
===========================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.isnumeric