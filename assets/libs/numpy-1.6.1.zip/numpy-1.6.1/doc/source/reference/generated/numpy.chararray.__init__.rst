numpy.chararray.__init__
========================

.. currentmodule:: numpy

.. automethod:: chararray.__init__