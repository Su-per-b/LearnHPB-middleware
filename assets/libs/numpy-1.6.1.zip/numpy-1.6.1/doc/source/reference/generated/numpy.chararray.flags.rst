numpy.chararray.flags
=====================

.. currentmodule:: numpy

.. autoattribute:: chararray.flags