numpy.broadcast.nd
==================

.. currentmodule:: numpy

.. autoattribute:: broadcast.nd