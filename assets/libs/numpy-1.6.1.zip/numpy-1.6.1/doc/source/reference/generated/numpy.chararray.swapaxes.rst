numpy.chararray.swapaxes
========================

.. currentmodule:: numpy

.. automethod:: chararray.swapaxes