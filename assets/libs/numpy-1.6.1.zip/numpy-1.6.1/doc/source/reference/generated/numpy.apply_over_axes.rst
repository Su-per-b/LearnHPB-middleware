numpy.apply_over_axes
=====================

.. currentmodule:: numpy

.. autofunction:: apply_over_axes