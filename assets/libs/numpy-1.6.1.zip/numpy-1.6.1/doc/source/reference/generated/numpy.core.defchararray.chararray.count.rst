numpy.core.defchararray.chararray.count
=======================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.count