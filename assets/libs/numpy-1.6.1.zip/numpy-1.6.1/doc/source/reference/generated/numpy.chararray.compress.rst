numpy.chararray.compress
========================

.. currentmodule:: numpy

.. automethod:: chararray.compress