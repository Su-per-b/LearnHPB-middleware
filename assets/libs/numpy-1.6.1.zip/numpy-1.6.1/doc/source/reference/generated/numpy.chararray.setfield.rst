numpy.chararray.setfield
========================

.. currentmodule:: numpy

.. automethod:: chararray.setfield