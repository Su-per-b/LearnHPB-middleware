numpy.bitwise_xor
=================

.. currentmodule:: numpy

.. autodata:: bitwise_xor