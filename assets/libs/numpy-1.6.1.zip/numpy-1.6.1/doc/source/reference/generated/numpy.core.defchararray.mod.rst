numpy.core.defchararray.mod
===========================

.. currentmodule:: numpy.core.defchararray

.. autofunction:: mod