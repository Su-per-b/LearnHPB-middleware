numpy.distutils.misc_util.filter_sources
========================================

.. currentmodule:: numpy.distutils.misc_util

.. autofunction:: filter_sources