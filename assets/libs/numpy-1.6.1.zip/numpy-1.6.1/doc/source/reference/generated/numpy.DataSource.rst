numpy.DataSource
================

.. currentmodule:: numpy

.. autoclass:: DataSource

   

   .. HACK
      .. autosummary::
         :toctree:
      
         DataSource.__init__
         DataSource.abspath
         DataSource.exists
         DataSource.open



   

