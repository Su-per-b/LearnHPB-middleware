numpy.core.defchararray.chararray.nbytes
========================================

.. currentmodule:: numpy.core.defchararray

.. autoattribute:: chararray.nbytes