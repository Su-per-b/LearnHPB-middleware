numpy.diag_indices_from
=======================

.. currentmodule:: numpy

.. autofunction:: diag_indices_from