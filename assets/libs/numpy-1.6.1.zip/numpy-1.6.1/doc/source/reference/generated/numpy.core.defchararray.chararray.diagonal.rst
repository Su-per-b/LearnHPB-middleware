numpy.core.defchararray.chararray.diagonal
==========================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.diagonal