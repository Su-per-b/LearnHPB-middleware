numpy.array_equiv
=================

.. currentmodule:: numpy

.. autofunction:: array_equiv