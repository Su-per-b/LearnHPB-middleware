numpy.core.defchararray.chararray.round
=======================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.round