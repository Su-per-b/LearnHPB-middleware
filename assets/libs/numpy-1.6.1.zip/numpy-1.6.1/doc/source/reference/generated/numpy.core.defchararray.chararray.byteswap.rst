numpy.core.defchararray.chararray.byteswap
==========================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.byteswap