numpy.core.defchararray.islower
===============================

.. currentmodule:: numpy.core.defchararray

.. autofunction:: islower