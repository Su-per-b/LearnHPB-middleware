numpy.core.defchararray.chararray.max
=====================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.max