numpy.chararray.tolist
======================

.. currentmodule:: numpy

.. automethod:: chararray.tolist