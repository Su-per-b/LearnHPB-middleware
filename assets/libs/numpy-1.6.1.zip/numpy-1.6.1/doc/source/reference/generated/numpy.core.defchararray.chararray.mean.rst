numpy.core.defchararray.chararray.mean
======================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.mean