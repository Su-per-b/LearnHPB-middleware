numpy.core.defchararray.chararray.copy
======================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.copy