numpy.deg2rad
=============

.. currentmodule:: numpy

.. autodata:: deg2rad