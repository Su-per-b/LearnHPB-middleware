numpy.cumprod
=============

.. currentmodule:: numpy

.. autofunction:: cumprod