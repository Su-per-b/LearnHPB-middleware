numpy.chararray.istitle
=======================

.. currentmodule:: numpy

.. automethod:: chararray.istitle