numpy.core.records.fromrecords
==============================

.. currentmodule:: numpy.core.records

.. autofunction:: fromrecords