numpy.broadcast_arrays
======================

.. currentmodule:: numpy

.. autofunction:: broadcast_arrays