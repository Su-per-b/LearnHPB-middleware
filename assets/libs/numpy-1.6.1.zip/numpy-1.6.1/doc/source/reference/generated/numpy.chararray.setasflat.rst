numpy.chararray.setasflat
=========================

.. currentmodule:: numpy

.. automethod:: chararray.setasflat