numpy.any
=========

.. currentmodule:: numpy

.. autofunction:: any