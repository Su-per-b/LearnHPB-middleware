numpy.core.defchararray.chararray.strides
=========================================

.. currentmodule:: numpy.core.defchararray

.. autoattribute:: chararray.strides