numpy.core.defchararray.ljust
=============================

.. currentmodule:: numpy.core.defchararray

.. autofunction:: ljust