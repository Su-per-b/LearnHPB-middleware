numpy.core.defchararray.chararray.islower
=========================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.islower