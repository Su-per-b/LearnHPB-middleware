numpy.chararray.encode
======================

.. currentmodule:: numpy

.. automethod:: chararray.encode