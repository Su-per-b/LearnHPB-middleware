numpy.cov
=========

.. currentmodule:: numpy

.. autofunction:: cov