numpy.core.defchararray.chararray.min
=====================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.min