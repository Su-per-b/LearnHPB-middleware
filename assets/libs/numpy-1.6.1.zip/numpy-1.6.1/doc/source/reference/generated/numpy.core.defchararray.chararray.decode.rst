numpy.core.defchararray.chararray.decode
========================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.decode