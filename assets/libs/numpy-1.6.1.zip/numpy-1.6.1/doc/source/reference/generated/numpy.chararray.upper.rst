numpy.chararray.upper
=====================

.. currentmodule:: numpy

.. automethod:: chararray.upper