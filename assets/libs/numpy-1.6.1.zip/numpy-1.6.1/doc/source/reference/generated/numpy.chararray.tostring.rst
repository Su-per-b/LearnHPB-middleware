numpy.chararray.tostring
========================

.. currentmodule:: numpy

.. automethod:: chararray.tostring