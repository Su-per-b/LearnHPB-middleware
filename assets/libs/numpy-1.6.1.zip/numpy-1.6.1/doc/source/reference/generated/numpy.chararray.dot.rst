numpy.chararray.dot
===================

.. currentmodule:: numpy

.. automethod:: chararray.dot