numpy.clip
==========

.. currentmodule:: numpy

.. autofunction:: clip