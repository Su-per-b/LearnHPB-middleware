numpy.chararray.translate
=========================

.. currentmodule:: numpy

.. automethod:: chararray.translate