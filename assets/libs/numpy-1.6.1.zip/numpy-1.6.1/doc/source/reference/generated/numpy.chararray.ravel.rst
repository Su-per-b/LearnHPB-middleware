numpy.chararray.ravel
=====================

.. currentmodule:: numpy

.. automethod:: chararray.ravel