numpy.chararray.dump
====================

.. currentmodule:: numpy

.. automethod:: chararray.dump