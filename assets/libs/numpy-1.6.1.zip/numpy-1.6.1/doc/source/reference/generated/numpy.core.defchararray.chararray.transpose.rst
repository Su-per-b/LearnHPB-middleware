numpy.core.defchararray.chararray.transpose
===========================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.transpose