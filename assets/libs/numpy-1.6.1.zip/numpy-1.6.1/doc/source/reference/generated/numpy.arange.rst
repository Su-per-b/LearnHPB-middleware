numpy.arange
============

.. currentmodule:: numpy

.. autofunction:: arange