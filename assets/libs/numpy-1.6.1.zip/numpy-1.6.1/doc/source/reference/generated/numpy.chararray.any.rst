numpy.chararray.any
===================

.. currentmodule:: numpy

.. automethod:: chararray.any