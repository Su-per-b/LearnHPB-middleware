numpy.core.defchararray.chararray.imag
======================================

.. currentmodule:: numpy.core.defchararray

.. autoattribute:: chararray.imag