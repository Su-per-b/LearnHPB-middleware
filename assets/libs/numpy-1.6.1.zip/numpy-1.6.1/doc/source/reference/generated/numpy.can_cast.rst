numpy.can_cast
==============

.. currentmodule:: numpy

.. autofunction:: can_cast