numpy.chararray.strides
=======================

.. currentmodule:: numpy

.. autoattribute:: chararray.strides