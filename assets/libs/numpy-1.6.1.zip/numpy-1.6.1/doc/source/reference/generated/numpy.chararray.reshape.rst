numpy.chararray.reshape
=======================

.. currentmodule:: numpy

.. automethod:: chararray.reshape