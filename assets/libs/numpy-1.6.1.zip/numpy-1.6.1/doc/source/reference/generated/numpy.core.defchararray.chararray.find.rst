numpy.core.defchararray.chararray.find
======================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.find