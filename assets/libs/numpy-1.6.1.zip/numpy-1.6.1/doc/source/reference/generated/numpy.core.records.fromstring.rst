numpy.core.records.fromstring
=============================

.. currentmodule:: numpy.core.records

.. autofunction:: fromstring