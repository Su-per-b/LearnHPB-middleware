numpy.cosh
==========

.. currentmodule:: numpy

.. autodata:: cosh