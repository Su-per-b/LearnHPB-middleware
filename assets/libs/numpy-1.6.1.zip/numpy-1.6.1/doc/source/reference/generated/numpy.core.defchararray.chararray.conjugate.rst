numpy.core.defchararray.chararray.conjugate
===========================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.conjugate