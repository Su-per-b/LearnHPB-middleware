numpy.core.defchararray.chararray.lstrip
========================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.lstrip