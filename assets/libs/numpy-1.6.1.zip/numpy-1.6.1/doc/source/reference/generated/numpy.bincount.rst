numpy.bincount
==============

.. currentmodule:: numpy

.. autofunction:: bincount