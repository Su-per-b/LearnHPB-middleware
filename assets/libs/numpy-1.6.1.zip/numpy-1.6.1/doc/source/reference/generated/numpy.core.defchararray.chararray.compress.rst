numpy.core.defchararray.chararray.compress
==========================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.compress