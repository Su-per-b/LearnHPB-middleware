numpy.core.defchararray.chararray.var
=====================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.var