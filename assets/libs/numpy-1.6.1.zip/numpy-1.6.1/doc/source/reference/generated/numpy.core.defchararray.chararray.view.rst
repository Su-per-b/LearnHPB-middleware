numpy.core.defchararray.chararray.view
======================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.view