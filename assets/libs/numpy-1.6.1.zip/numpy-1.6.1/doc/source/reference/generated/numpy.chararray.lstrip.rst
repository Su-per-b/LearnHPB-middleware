numpy.chararray.lstrip
======================

.. currentmodule:: numpy

.. automethod:: chararray.lstrip