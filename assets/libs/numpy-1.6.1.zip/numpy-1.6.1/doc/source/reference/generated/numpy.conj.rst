numpy.conj
==========

.. currentmodule:: numpy

.. autodata:: conj