numpy.chararray.argmin
======================

.. currentmodule:: numpy

.. automethod:: chararray.argmin