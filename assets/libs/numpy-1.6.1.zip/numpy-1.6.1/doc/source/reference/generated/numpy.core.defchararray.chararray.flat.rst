numpy.core.defchararray.chararray.flat
======================================

.. currentmodule:: numpy.core.defchararray

.. autoattribute:: chararray.flat