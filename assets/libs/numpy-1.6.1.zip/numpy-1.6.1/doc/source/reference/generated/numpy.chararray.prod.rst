numpy.chararray.prod
====================

.. currentmodule:: numpy

.. automethod:: chararray.prod