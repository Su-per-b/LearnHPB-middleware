numpy.core.defchararray.chararray.sort
======================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.sort