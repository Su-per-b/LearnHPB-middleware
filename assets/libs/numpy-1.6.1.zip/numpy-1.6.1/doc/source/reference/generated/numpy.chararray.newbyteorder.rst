numpy.chararray.newbyteorder
============================

.. currentmodule:: numpy

.. automethod:: chararray.newbyteorder