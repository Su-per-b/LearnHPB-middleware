numpy.core.defchararray.chararray.startswith
============================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.startswith