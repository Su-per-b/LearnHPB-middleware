numpy.chararray.rjust
=====================

.. currentmodule:: numpy

.. automethod:: chararray.rjust