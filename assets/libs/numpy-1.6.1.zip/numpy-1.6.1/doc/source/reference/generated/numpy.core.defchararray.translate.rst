numpy.core.defchararray.translate
=================================

.. currentmodule:: numpy.core.defchararray

.. autofunction:: translate