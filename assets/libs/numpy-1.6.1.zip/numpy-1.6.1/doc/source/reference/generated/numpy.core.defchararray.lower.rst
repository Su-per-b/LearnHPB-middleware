numpy.core.defchararray.lower
=============================

.. currentmodule:: numpy.core.defchararray

.. autofunction:: lower