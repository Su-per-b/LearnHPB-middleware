numpy.chararray.lower
=====================

.. currentmodule:: numpy

.. automethod:: chararray.lower