numpy.core.defchararray.chararray.ptp
=====================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.ptp