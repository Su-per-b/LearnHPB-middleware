numpy.core.defchararray.chararray.astype
========================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.astype