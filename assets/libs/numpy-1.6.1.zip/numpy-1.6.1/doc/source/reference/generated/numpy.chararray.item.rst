numpy.chararray.item
====================

.. currentmodule:: numpy

.. automethod:: chararray.item