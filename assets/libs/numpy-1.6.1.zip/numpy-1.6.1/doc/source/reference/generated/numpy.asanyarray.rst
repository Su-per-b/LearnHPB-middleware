numpy.asanyarray
================

.. currentmodule:: numpy

.. autofunction:: asanyarray