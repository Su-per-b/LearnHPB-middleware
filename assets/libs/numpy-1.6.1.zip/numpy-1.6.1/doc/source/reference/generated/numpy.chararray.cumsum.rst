numpy.chararray.cumsum
======================

.. currentmodule:: numpy

.. automethod:: chararray.cumsum