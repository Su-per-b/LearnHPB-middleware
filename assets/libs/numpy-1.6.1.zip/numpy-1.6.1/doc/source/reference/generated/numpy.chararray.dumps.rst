numpy.chararray.dumps
=====================

.. currentmodule:: numpy

.. automethod:: chararray.dumps