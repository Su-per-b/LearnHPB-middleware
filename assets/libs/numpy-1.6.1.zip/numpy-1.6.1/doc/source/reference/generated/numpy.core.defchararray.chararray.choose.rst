numpy.core.defchararray.chararray.choose
========================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.choose