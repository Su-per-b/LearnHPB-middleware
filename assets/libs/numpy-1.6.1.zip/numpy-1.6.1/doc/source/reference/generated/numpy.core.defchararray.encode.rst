numpy.core.defchararray.encode
==============================

.. currentmodule:: numpy.core.defchararray

.. autofunction:: encode