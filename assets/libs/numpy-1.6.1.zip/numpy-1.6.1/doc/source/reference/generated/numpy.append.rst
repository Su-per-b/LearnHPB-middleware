numpy.append
============

.. currentmodule:: numpy

.. autofunction:: append