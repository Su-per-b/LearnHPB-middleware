numpy.chararray.isupper
=======================

.. currentmodule:: numpy

.. automethod:: chararray.isupper