numpy.core.defchararray.chararray.setasflat
===========================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.setasflat