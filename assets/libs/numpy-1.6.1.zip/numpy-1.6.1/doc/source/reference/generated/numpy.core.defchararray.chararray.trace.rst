numpy.core.defchararray.chararray.trace
=======================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.trace