numpy.chararray.size
====================

.. currentmodule:: numpy

.. autoattribute:: chararray.size