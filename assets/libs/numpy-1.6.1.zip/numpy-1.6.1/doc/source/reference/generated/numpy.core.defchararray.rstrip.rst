numpy.core.defchararray.rstrip
==============================

.. currentmodule:: numpy.core.defchararray

.. autofunction:: rstrip