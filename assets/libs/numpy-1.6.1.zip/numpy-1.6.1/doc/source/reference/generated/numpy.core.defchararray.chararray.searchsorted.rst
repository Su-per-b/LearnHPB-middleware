numpy.core.defchararray.chararray.searchsorted
==============================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.searchsorted