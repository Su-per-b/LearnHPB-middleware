numpy.core.defchararray.multiply
================================

.. currentmodule:: numpy.core.defchararray

.. autofunction:: multiply