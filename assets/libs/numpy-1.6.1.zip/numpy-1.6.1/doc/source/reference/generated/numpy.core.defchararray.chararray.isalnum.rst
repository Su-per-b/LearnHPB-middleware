numpy.core.defchararray.chararray.isalnum
=========================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.isalnum