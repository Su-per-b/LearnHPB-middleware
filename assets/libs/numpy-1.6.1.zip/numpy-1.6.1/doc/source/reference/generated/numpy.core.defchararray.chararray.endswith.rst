numpy.core.defchararray.chararray.endswith
==========================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.endswith