numpy.core.defchararray.greater
===============================

.. currentmodule:: numpy.core.defchararray

.. autofunction:: greater