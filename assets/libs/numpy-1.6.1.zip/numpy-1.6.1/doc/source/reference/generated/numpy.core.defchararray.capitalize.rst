numpy.core.defchararray.capitalize
==================================

.. currentmodule:: numpy.core.defchararray

.. autofunction:: capitalize