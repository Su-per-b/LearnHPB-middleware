numpy.choose
============

.. currentmodule:: numpy

.. autofunction:: choose