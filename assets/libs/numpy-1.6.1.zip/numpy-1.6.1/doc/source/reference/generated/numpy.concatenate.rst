numpy.concatenate
=================

.. currentmodule:: numpy

.. autofunction:: concatenate