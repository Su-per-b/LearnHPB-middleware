numpy.chararray.take
====================

.. currentmodule:: numpy

.. automethod:: chararray.take