numpy.count_nonzero
===================

.. currentmodule:: numpy

.. autofunction:: count_nonzero