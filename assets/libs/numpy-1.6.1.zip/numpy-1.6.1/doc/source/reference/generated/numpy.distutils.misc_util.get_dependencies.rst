numpy.distutils.misc_util.get_dependencies
==========================================

.. currentmodule:: numpy.distutils.misc_util

.. autofunction:: get_dependencies