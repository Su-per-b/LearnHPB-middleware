numpy.core.defchararray.chararray.dump
======================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.dump