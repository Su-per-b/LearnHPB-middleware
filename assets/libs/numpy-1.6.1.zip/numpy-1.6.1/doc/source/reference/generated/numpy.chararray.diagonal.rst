numpy.chararray.diagonal
========================

.. currentmodule:: numpy

.. automethod:: chararray.diagonal