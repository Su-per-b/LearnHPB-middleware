numpy.copysign
==============

.. currentmodule:: numpy

.. autodata:: copysign