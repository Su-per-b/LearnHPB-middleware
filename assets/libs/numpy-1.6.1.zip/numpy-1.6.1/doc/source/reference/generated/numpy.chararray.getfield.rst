numpy.chararray.getfield
========================

.. currentmodule:: numpy

.. automethod:: chararray.getfield