numpy.chararray.itemsize
========================

.. currentmodule:: numpy

.. autoattribute:: chararray.itemsize