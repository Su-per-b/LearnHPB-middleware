numpy.core.defchararray.chararray.__init__
==========================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.__init__