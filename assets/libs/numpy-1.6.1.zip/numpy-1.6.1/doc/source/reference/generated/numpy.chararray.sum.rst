numpy.chararray.sum
===================

.. currentmodule:: numpy

.. automethod:: chararray.sum