numpy.core.defchararray.rfind
=============================

.. currentmodule:: numpy.core.defchararray

.. autofunction:: rfind