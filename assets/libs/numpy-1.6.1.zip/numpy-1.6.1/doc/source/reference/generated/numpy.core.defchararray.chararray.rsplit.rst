numpy.core.defchararray.chararray.rsplit
========================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.rsplit