numpy.core.defchararray.chararray.nonzero
=========================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.nonzero