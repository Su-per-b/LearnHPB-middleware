numpy.diff
==========

.. currentmodule:: numpy

.. autofunction:: diff