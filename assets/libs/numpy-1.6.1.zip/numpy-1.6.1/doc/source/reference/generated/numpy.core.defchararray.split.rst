numpy.core.defchararray.split
=============================

.. currentmodule:: numpy.core.defchararray

.. autofunction:: split