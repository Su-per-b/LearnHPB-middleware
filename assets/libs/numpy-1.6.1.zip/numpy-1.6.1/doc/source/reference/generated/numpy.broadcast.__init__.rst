numpy.broadcast.__init__
========================

.. currentmodule:: numpy

.. automethod:: broadcast.__init__