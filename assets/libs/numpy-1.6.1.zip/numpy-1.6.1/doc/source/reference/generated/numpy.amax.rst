numpy.amax
==========

.. currentmodule:: numpy

.. autofunction:: amax