numpy.chararray.std
===================

.. currentmodule:: numpy

.. automethod:: chararray.std