numpy.alterdot
==============

.. currentmodule:: numpy

.. autofunction:: alterdot