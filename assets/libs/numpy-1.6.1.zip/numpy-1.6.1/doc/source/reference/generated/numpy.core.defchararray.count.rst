numpy.core.defchararray.count
=============================

.. currentmodule:: numpy.core.defchararray

.. autofunction:: count