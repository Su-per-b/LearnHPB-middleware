numpy.chararray.conjugate
=========================

.. currentmodule:: numpy

.. automethod:: chararray.conjugate