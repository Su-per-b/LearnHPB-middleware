numpy.core.defchararray.chararray.rjust
=======================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.rjust