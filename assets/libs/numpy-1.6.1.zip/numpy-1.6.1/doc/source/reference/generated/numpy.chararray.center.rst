numpy.chararray.center
======================

.. currentmodule:: numpy

.. automethod:: chararray.center