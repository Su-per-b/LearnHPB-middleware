numpy.chararray.isdecimal
=========================

.. currentmodule:: numpy

.. automethod:: chararray.isdecimal