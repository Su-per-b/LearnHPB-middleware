numpy.core.defchararray.chararray.sum
=====================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.sum