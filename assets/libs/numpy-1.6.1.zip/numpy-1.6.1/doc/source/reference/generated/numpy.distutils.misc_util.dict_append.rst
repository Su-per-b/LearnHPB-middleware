numpy.distutils.misc_util.dict_append
=====================================

.. currentmodule:: numpy.distutils.misc_util

.. autofunction:: dict_append