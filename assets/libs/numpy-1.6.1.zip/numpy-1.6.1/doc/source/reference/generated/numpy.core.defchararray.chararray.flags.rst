numpy.core.defchararray.chararray.flags
=======================================

.. currentmodule:: numpy.core.defchararray

.. autoattribute:: chararray.flags