numpy.chararray.conj
====================

.. currentmodule:: numpy

.. automethod:: chararray.conj