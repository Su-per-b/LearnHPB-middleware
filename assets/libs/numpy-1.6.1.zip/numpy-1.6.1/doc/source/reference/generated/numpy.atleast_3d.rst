numpy.atleast_3d
================

.. currentmodule:: numpy

.. autofunction:: atleast_3d