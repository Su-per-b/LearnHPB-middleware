numpy.average
=============

.. currentmodule:: numpy

.. autofunction:: average