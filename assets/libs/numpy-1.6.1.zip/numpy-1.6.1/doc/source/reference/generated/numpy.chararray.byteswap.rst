numpy.chararray.byteswap
========================

.. currentmodule:: numpy

.. automethod:: chararray.byteswap