numpy.chararray.rindex
======================

.. currentmodule:: numpy

.. automethod:: chararray.rindex