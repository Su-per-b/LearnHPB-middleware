numpy.core.defchararray.chararray.conj
======================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.conj