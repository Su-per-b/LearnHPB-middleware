numpy.core.defchararray.chararray.prod
======================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.prod