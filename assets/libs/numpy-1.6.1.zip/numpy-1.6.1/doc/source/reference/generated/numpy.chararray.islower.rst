numpy.chararray.islower
=======================

.. currentmodule:: numpy

.. automethod:: chararray.islower