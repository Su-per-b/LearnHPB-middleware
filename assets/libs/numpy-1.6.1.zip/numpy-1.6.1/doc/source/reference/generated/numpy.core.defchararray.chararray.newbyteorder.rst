numpy.core.defchararray.chararray.newbyteorder
==============================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.newbyteorder