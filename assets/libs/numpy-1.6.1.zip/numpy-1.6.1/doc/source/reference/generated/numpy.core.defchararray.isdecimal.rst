numpy.core.defchararray.isdecimal
=================================

.. currentmodule:: numpy.core.defchararray

.. autofunction:: isdecimal