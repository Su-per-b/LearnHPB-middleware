numpy.distutils.misc_util.appendpath
====================================

.. currentmodule:: numpy.distutils.misc_util

.. autofunction:: appendpath