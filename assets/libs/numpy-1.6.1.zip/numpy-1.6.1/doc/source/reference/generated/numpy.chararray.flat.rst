numpy.chararray.flat
====================

.. currentmodule:: numpy

.. autoattribute:: chararray.flat