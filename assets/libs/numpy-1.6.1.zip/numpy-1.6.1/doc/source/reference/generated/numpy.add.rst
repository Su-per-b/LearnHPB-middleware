numpy.add
=========

.. currentmodule:: numpy

.. autodata:: add