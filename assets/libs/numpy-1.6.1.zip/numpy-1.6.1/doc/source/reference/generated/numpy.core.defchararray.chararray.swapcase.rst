numpy.core.defchararray.chararray.swapcase
==========================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.swapcase