numpy.chararray
===============

.. currentmodule:: numpy

.. autoclass:: chararray

   

   .. HACK
      .. autosummary::
         :toctree:
      
         chararray.__init__
         chararray.all
         chararray.any
         chararray.argmax
         chararray.argmin
         chararray.argsort
         chararray.astype
         chararray.byteswap
         chararray.capitalize
         chararray.center
         chararray.choose
         chararray.clip
         chararray.compress
         chararray.conj
         chararray.conjugate
         chararray.copy
         chararray.count
         chararray.cumprod
         chararray.cumsum
         chararray.decode
         chararray.diagonal
         chararray.dot
         chararray.dump
         chararray.dumps
         chararray.encode
         chararray.endswith
         chararray.expandtabs
         chararray.fill
         chararray.find
         chararray.flatten
         chararray.getfield
         chararray.index
         chararray.isalnum
         chararray.isalpha
         chararray.isdecimal
         chararray.isdigit
         chararray.islower
         chararray.isnumeric
         chararray.isspace
         chararray.istitle
         chararray.isupper
         chararray.item
         chararray.itemset
         chararray.join
         chararray.ljust
         chararray.lower
         chararray.lstrip
         chararray.max
         chararray.mean
         chararray.min
         chararray.newbyteorder
         chararray.nonzero
         chararray.partition
         chararray.prod
         chararray.ptp
         chararray.put
         chararray.ravel
         chararray.repeat
         chararray.replace
         chararray.reshape
         chararray.resize
         chararray.rfind
         chararray.rindex
         chararray.rjust
         chararray.round
         chararray.rpartition
         chararray.rsplit
         chararray.rstrip
         chararray.searchsorted
         chararray.setasflat
         chararray.setfield
         chararray.setflags
         chararray.sort
         chararray.split
         chararray.splitlines
         chararray.squeeze
         chararray.startswith
         chararray.std
         chararray.strip
         chararray.sum
         chararray.swapaxes
         chararray.swapcase
         chararray.take
         chararray.title
         chararray.tofile
         chararray.tolist
         chararray.tostring
         chararray.trace
         chararray.translate
         chararray.transpose
         chararray.upper
         chararray.var
         chararray.view
         chararray.zfill



   

   .. HACK
      .. autosummary::
         :toctree:
      
         chararray.T
         chararray.base
         chararray.ctypes
         chararray.data
         chararray.dtype
         chararray.flags
         chararray.flat
         chararray.imag
         chararray.itemsize
         chararray.nbytes
         chararray.ndim
         chararray.real
         chararray.shape
         chararray.size
         chararray.strides

