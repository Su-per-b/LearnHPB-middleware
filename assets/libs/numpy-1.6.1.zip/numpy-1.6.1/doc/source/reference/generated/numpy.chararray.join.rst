numpy.chararray.join
====================

.. currentmodule:: numpy

.. automethod:: chararray.join