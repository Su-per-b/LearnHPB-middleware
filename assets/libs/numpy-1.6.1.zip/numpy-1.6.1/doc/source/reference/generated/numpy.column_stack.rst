numpy.column_stack
==================

.. currentmodule:: numpy

.. autofunction:: column_stack