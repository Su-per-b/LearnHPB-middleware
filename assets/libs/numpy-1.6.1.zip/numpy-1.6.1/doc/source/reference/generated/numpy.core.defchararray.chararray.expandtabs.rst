numpy.core.defchararray.chararray.expandtabs
============================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.expandtabs