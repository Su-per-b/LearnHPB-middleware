numpy.core.defchararray.chararray.ravel
=======================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.ravel