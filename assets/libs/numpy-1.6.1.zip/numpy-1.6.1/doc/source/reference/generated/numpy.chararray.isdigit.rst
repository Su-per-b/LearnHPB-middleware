numpy.chararray.isdigit
=======================

.. currentmodule:: numpy

.. automethod:: chararray.isdigit