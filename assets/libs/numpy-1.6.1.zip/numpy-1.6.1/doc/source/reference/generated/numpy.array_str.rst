numpy.array_str
===============

.. currentmodule:: numpy

.. autofunction:: array_str