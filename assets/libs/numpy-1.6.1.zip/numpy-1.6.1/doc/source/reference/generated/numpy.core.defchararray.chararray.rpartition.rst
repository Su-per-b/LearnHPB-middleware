numpy.core.defchararray.chararray.rpartition
============================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.rpartition