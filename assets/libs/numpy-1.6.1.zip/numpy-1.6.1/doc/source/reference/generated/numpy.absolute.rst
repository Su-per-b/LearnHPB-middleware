numpy.absolute
==============

.. currentmodule:: numpy

.. autodata:: absolute