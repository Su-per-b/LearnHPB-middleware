numpy.core.defchararray.chararray.dtype
=======================================

.. currentmodule:: numpy.core.defchararray

.. autoattribute:: chararray.dtype