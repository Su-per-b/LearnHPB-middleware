numpy.core.defchararray.chararray.item
======================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.item