numpy.core.defchararray.chararray.reshape
=========================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.reshape