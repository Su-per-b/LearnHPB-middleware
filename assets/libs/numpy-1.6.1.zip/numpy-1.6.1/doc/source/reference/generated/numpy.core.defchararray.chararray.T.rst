numpy.core.defchararray.chararray.T
===================================

.. currentmodule:: numpy.core.defchararray

.. autoattribute:: chararray.T