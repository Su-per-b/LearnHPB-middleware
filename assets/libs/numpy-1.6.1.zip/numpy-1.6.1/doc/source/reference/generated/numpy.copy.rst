numpy.copy
==========

.. currentmodule:: numpy

.. autofunction:: copy