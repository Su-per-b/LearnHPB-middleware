numpy.core.defchararray.chararray.center
========================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.center