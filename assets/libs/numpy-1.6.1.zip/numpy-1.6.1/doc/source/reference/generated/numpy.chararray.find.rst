numpy.chararray.find
====================

.. currentmodule:: numpy

.. automethod:: chararray.find