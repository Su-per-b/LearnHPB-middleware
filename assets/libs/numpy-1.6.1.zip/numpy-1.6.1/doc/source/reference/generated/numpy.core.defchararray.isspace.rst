numpy.core.defchararray.isspace
===============================

.. currentmodule:: numpy.core.defchararray

.. autofunction:: isspace