numpy.core.defchararray.chararray.ljust
=======================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.ljust