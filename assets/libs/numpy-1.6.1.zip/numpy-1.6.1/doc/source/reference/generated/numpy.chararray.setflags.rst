numpy.chararray.setflags
========================

.. currentmodule:: numpy

.. automethod:: chararray.setflags