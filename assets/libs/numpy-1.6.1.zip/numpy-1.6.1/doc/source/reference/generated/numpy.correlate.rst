numpy.correlate
===============

.. currentmodule:: numpy

.. autofunction:: correlate