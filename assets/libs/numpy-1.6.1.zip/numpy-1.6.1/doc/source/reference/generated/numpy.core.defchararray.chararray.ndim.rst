numpy.core.defchararray.chararray.ndim
======================================

.. currentmodule:: numpy.core.defchararray

.. autoattribute:: chararray.ndim