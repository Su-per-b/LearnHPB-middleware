numpy.core.defchararray.asarray
===============================

.. currentmodule:: numpy.core.defchararray

.. autofunction:: asarray