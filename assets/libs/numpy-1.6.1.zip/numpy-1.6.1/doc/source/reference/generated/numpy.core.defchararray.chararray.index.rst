numpy.core.defchararray.chararray.index
=======================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.index