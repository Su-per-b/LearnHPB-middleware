numpy.chararray.nbytes
======================

.. currentmodule:: numpy

.. autoattribute:: chararray.nbytes