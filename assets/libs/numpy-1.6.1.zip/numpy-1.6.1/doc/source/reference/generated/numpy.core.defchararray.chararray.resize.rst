numpy.core.defchararray.chararray.resize
========================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.resize