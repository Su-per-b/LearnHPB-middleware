numpy.core.defchararray.chararray.repeat
========================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.repeat