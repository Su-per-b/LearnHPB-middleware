numpy.chararray.argsort
=======================

.. currentmodule:: numpy

.. automethod:: chararray.argsort