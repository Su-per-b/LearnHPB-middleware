numpy.core.defchararray.less
============================

.. currentmodule:: numpy.core.defchararray

.. autofunction:: less