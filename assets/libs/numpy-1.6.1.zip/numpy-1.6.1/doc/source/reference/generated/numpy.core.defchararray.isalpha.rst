numpy.core.defchararray.isalpha
===============================

.. currentmodule:: numpy.core.defchararray

.. autofunction:: isalpha