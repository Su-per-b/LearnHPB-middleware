numpy.diagonal
==============

.. currentmodule:: numpy

.. autofunction:: diagonal