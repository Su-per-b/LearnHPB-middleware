numpy.broadcast
===============

.. currentmodule:: numpy

.. autoclass:: broadcast

   

   .. HACK
      .. autosummary::
         :toctree:
      
         broadcast.__init__
         broadcast.next
         broadcast.reset



   

   .. HACK
      .. autosummary::
         :toctree:
      
         broadcast.index
         broadcast.iters
         broadcast.nd
         broadcast.numiter
         broadcast.shape
         broadcast.size

