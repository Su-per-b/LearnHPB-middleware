numpy.core.defchararray.chararray.title
=======================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.title