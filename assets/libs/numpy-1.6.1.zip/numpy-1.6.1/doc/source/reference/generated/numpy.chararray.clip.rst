numpy.chararray.clip
====================

.. currentmodule:: numpy

.. automethod:: chararray.clip