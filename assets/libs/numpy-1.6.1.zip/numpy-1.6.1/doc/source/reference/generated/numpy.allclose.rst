numpy.allclose
==============

.. currentmodule:: numpy

.. autofunction:: allclose