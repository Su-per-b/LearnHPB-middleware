numpy.chararray.transpose
=========================

.. currentmodule:: numpy

.. automethod:: chararray.transpose