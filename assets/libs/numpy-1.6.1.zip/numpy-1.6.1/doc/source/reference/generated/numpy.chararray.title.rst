numpy.chararray.title
=====================

.. currentmodule:: numpy

.. automethod:: chararray.title