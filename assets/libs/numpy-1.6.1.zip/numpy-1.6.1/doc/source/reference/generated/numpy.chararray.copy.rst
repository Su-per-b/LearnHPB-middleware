numpy.chararray.copy
====================

.. currentmodule:: numpy

.. automethod:: chararray.copy