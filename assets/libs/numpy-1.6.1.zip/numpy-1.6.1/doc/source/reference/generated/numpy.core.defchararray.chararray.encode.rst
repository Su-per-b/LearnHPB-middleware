numpy.core.defchararray.chararray.encode
========================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.encode