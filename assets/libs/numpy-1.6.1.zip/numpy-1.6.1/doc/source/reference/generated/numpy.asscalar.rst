numpy.asscalar
==============

.. currentmodule:: numpy

.. autofunction:: asscalar