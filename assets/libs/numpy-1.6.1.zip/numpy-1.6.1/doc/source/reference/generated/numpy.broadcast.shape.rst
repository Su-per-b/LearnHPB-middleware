numpy.broadcast.shape
=====================

.. currentmodule:: numpy

.. autoattribute:: broadcast.shape