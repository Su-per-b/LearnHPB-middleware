numpy.DataSource.open
=====================

.. currentmodule:: numpy

.. automethod:: DataSource.open