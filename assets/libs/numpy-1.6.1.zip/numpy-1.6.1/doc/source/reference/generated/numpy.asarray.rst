numpy.asarray
=============

.. currentmodule:: numpy

.. autofunction:: asarray