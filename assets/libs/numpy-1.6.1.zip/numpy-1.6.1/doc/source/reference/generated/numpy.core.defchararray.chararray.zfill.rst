numpy.core.defchararray.chararray.zfill
=======================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.zfill