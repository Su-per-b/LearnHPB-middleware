numpy.chararray.isalnum
=======================

.. currentmodule:: numpy

.. automethod:: chararray.isalnum