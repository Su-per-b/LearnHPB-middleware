numpy.common_type
=================

.. currentmodule:: numpy

.. autofunction:: common_type