numpy.core.records.fromfile
===========================

.. currentmodule:: numpy.core.records

.. autofunction:: fromfile