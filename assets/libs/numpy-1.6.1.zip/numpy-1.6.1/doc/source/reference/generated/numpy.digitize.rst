numpy.digitize
==============

.. currentmodule:: numpy

.. autofunction:: digitize