numpy.core.defchararray.chararray.isalpha
=========================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.isalpha