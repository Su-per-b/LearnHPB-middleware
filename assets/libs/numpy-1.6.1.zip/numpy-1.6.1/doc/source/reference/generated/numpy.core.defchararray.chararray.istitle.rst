numpy.core.defchararray.chararray.istitle
=========================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.istitle