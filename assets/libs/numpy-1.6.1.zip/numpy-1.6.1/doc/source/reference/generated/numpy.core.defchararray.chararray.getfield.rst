numpy.core.defchararray.chararray.getfield
==========================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.getfield