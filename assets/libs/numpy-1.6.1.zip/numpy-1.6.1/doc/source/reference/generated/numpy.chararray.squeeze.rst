numpy.chararray.squeeze
=======================

.. currentmodule:: numpy

.. automethod:: chararray.squeeze