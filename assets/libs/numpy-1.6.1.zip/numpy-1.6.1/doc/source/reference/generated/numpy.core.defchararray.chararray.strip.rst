numpy.core.defchararray.chararray.strip
=======================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.strip