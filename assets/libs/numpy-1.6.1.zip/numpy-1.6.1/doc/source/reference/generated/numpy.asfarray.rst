numpy.asfarray
==============

.. currentmodule:: numpy

.. autofunction:: asfarray