numpy.chararray.sort
====================

.. currentmodule:: numpy

.. automethod:: chararray.sort