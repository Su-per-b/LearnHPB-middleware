numpy.core.defchararray.decode
==============================

.. currentmodule:: numpy.core.defchararray

.. autofunction:: decode