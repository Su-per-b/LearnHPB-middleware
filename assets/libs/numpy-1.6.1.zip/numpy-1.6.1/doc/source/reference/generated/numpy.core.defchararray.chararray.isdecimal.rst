numpy.core.defchararray.chararray.isdecimal
===========================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.isdecimal