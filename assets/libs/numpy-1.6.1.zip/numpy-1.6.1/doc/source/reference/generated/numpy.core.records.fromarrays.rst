numpy.core.records.fromarrays
=============================

.. currentmodule:: numpy.core.records

.. autofunction:: fromarrays