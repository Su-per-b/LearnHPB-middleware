numpy.chararray.index
=====================

.. currentmodule:: numpy

.. automethod:: chararray.index