numpy.core.defchararray.strip
=============================

.. currentmodule:: numpy.core.defchararray

.. autofunction:: strip