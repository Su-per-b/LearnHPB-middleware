numpy.DataSource.exists
=======================

.. currentmodule:: numpy

.. automethod:: DataSource.exists