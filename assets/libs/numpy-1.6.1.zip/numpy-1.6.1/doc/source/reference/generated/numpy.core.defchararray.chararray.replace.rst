numpy.core.defchararray.chararray.replace
=========================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.replace