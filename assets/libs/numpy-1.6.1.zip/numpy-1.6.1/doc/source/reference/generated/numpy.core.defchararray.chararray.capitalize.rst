numpy.core.defchararray.chararray.capitalize
============================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.capitalize