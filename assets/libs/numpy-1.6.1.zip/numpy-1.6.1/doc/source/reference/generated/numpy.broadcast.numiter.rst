numpy.broadcast.numiter
=======================

.. currentmodule:: numpy

.. autoattribute:: broadcast.numiter