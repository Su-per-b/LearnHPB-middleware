numpy.chararray.startswith
==========================

.. currentmodule:: numpy

.. automethod:: chararray.startswith