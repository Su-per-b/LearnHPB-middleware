numpy.core.defchararray.chararray.ctypes
========================================

.. currentmodule:: numpy.core.defchararray

.. autoattribute:: chararray.ctypes