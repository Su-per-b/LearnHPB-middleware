numpy.core.defchararray.zfill
=============================

.. currentmodule:: numpy.core.defchararray

.. autofunction:: zfill