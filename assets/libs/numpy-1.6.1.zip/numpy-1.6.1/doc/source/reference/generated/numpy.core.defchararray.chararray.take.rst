numpy.core.defchararray.chararray.take
======================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.take