numpy.core.defchararray.chararray.real
======================================

.. currentmodule:: numpy.core.defchararray

.. autoattribute:: chararray.real