numpy.core.defchararray.chararray.upper
=======================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.upper