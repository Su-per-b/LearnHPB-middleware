numpy.cross
===========

.. currentmodule:: numpy

.. autofunction:: cross