numpy.core.defchararray.isdigit
===============================

.. currentmodule:: numpy.core.defchararray

.. autofunction:: isdigit