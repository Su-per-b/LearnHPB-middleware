numpy.core.defchararray.chararray.put
=====================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.put