numpy.array_split
=================

.. currentmodule:: numpy

.. autofunction:: array_split