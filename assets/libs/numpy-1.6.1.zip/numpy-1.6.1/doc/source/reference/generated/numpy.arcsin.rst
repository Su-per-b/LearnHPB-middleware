numpy.arcsin
============

.. currentmodule:: numpy

.. autodata:: arcsin