numpy.core.defchararray.chararray.size
======================================

.. currentmodule:: numpy.core.defchararray

.. autoattribute:: chararray.size