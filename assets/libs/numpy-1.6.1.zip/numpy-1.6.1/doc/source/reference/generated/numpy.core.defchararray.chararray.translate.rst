numpy.core.defchararray.chararray.translate
===========================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.translate