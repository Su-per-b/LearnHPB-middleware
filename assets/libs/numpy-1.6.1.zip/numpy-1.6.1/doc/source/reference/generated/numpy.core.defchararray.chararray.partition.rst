numpy.core.defchararray.chararray.partition
===========================================

.. currentmodule:: numpy.core.defchararray

.. automethod:: chararray.partition