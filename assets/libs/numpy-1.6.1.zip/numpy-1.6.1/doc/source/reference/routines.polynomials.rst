Polynomials
***********

The poly1d functions are considered outdated but are retained for
backward compatibility. New software needing polynomials should
use the classes in the Polynomial Package.

.. toctree::
   :maxdepth: 2

   routines.polynomials.polynomial
   routines.polynomials.poly1d


